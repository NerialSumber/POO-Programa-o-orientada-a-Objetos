
package fatec.poo.model;

/**
 *
 * @author Gabe
 */
public class Palestra {
    private String data, tema;
    private double valor;
    private Palestrante[] palestrantes;
    private Participante[] participantes;
    private int numPart, numPales;
    
    public Palestra(String tema, double valor) {
        this.tema = tema;
        this.valor = valor;
        palestrantes = new Palestrante[2];
        participantes = new Participante[3];
        numPart = 0;
        numPales = 0;
    }

    public String getTema() {
        return tema;
    }

    public double getValor() {
        return valor;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
    
    public void addPalestrante(Palestrante p) {
        palestrantes[numPales] = p;
        numPales = numPales + 1;
    }
    
    public void addParticipante(Participante p) {
        participantes[numPart] = p;
        numPart = numPart + 1;
    }
    
    public double calcTotalFaturado() {
        double valTotal = 0.0;
        
        for(int i = 0; i < 3; i++) {
            if(participantes[i].getTipo() == 'C') {
              valTotal = valTotal + valor;  
            }
            else {
                if(participantes[i].getTipo() == 'E') {
                    valTotal = valTotal + (valor * 0.15);                    
                }
                else {
                    valTotal = valTotal + (valor * 0.20);
                }
            }
        }
        return (valTotal);
    }
}
