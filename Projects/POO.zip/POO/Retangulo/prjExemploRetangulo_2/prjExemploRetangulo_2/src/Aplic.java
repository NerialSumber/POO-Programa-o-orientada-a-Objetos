
import java.util.Scanner;

/**
 *
 * @author Gabe
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int opcao;
        double medAlt, medBase;
        
        System.out.print("Digite a medida da altura: ");
        medAlt = entrada.nextDouble(); //sacnf("%lf", &medAlt)
        System.out.print("Digite a medida da base: ");
        medBase = entrada.nextDouble(); //scanf("%lf", &medBase)
        
        Retangulo objRet = new Retangulo();
        
        //Passagem de mensagens
        objRet.setAltura(medAlt);
        objRet.setBase(medBase);
        
        do {
            System.out.println("\n\n1 - Consultar Área");
            System.out.println("2 - Consultar Perímetro");
            System.out.println("3 - Consultar Diagonal");
            System.out.println("4 - Sair");
            System.out.println("\n\t\tDigite a opção: ");
            opcao = entrada.nextInt();
            
            System.out.println("A medida da área: " + objRet.getAltura());
            System.out.println("A medida da base: " + objRet.getBase());
            
            if(opcao == 1) {
                System.out.println("\nA medida da área do retângulo: " + objRet.calcArea());
            }
            else {
                if(opcao == 2) {
                    System.out.println("\nA medida do perímetro do retândulo: " + objRet.calcPerimetro());
                }
                else {
                    if(opcao == 3) {
                        System.out.println("\nA medida da diagonal do retângulo: " + objRet.calcDiagonal());
                    }
                }        
            }
        } while(opcao < 4);
    }
    
}
