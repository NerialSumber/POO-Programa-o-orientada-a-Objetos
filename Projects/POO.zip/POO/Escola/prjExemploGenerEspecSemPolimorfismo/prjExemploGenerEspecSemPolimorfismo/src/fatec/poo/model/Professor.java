
package fatec.poo.model;

/**
 *
 * @author Gabe
 */
public class Professor extends Pessoa {
    private int regFuncional;
    private double salario;
    
    public Professor(int f, String n, String dn) {
        super(n, dn);
        regFuncional = f; 
    }
    
    public void setSalario(double s){
        salario = s;
    }
    
    public int getRegFuncional() {
        return regFuncional;
    }
    
    public double getSalario() {
        return salario;
    }
}
