
import java.util.Scanner;

/**
 *
 * @author Gabe
 */

public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double medRaio;
        
        System.out.println("Digite o raio do círculo: ");
        medRaio = entrada.nextDouble();
        
        Circulo objCirc = new Circulo();
        
        objCirc.setRaio(medRaio);
        
        System.out.println("\n------------------------------------");
        System.out.println("A medida do raio do círculo:      " + objCirc.getRaio());
        System.out.println("\nA medida da área do círculo:      " + objCirc.calcArea());
        System.out.println("A medida do perímetro do círculo: " + objCirc.calcPerimetro());
        System.out.println("A medida do diâmetro do círculo:  " + objCirc.calcDiametro());
        System.out.println("------------------------------------");
    }
}
