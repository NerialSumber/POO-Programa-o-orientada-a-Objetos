/**
 *
 * @author Yuki
 */
public class ContaCorrente {
    private int numero;
    private double saldo;
    
    public ContaCorrente(int num, double sal) {
        numero = num;
        saldo = sal;
    }
    
    public int getNumero() {
        return numero;
    }
    
    public double getSaldo() {
        return saldo;
    }
    
    public void sacar(double s) {
        saldo = saldo - s;
    }
    
    public void depositar(double d) {
        saldo = saldo + d;
    }
}
