
import java.util.Scanner;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numConta, opcao;
        double salConta, saque, deposito;
        
        System.out.println("Digite o número da conta: ");
        numConta = entrada.nextInt();
        System.out.println("Digite o saldo da conta: ");
        salConta = entrada.nextDouble();
        
        ContaCorrente objConta = new ContaCorrente(numConta, salConta);
        
        do {
            System.out.println("\n1 - Depositar");
            System.out.println("2 - Sacar");
            System.out.println("3 - Consultar Saldo");
            System.out.println("4 - Sair");
            System.out.println("\t\tDigite a opção: ");
            opcao = entrada.nextInt();
            
            if(opcao >= 1 && opcao < 4) {
                System.out.println("\nNúmero da conta corrente: " + objConta.getNumero());
            }
            
            switch(opcao) {
                case 1:
                    System.out.println("-----------------------------------");
                    System.out.println("Digite o valor do depósito: ");
                    deposito = entrada.nextDouble();
                    objConta.depositar(deposito);
                    System.out.println("\nO depósito foi realizado com sucesso!");
                    System.out.println("-----------------------------------");
                    break;
                case 2:
                    System.out.println("-----------------------------------");
                    System.out.println("Digite o valor do saque: ");
                    saque = entrada.nextDouble();
                    
                    if(saque > objConta.getSaldo()) {
                        System.out.println("\nSaldo Insuficiente");
                    }
                    else {
                        objConta.sacar(saque);
                        System.out.println("\nO saque foi realizado com sucesso!");
                    }
                    System.out.println("-----------------------------------");
                    break;
                case 3:
                    System.out.println("-----------------------------------");
                    System.out.println("O valor do saldo: " + objConta.getSaldo());
                    System.out.println("-----------------------------------");
                    break;
                case 4:
                    break;
            }
        } while(opcao < 4);
    }
}
