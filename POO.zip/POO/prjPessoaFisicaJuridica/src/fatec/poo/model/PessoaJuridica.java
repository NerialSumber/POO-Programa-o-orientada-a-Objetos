package fatec.poo.model;

/**
 *
 * @author gabri
 */
public class PessoaJuridica extends Pessoa {
    private String cgc;
    private double taxaIncentivo;
    
    public PessoaJuridica( String c, String n, int a) {
        super( n, a);
        cgc = c;
    }
    
    public void setTaxaIncentivo( double ti) {
        taxaIncentivo = ti;
    }
    
    public double getTaxaIncentivo() {
        return(taxaIncentivo);
    }
    
    public double calcBonus(int aAtual) {
        return(taxaIncentivo * super.getTotalCompras()) * (aAtual - super.getAnoInscr()); 
    }
    
    public String getCgc() {
        return(cgc);
    }
}
