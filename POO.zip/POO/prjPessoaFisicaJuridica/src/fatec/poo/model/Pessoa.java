package fatec.poo.model;

/**
 *
 * @author gabri
 */
public abstract class Pessoa {
    private String nome;
    private int anoInscr;
    private double totalCompras;
    
    public Pessoa (String n, int a) {
        nome = n;
        anoInscr = a;

    }
    
    abstract public double calcBonus(int aAtual);
    
    public void addCompras(double tc){
        totalCompras =+ tc;
    }
    
    public String getNome(){
        return (nome);
    }
    
    public int getAnoInscr(){
        return (anoInscr);
    }
    
    public double getTotalCompras(){
        return (totalCompras);
    }
}
