import fatec.poo.model.PessoaFisica;
import fatec.poo.model.PessoaJuridica;
import fatec.poo.model.Pessoa;
import java.text.DecimalFormat;
import java.util.Scanner;
/**
 *
 * @author gabri
 */
public class Aplic {
    public static void main(String[] args) {
        String nome, cpf, cgc;
        int anoInscr, aAtual, opcao, opcao2;
        double totalCompras, base, ti, compras;
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        System.out.println("Digite Ano Atual: ");
        aAtual = entrada.nextInt();
        entrada.nextLine();
        
        System.out.println("Digite seu CPF: ");
        cpf = entrada.nextLine();
        
        System.out.println("Digite seu Nome: ");
        nome = entrada.nextLine();
        
        System.out.println("Informe o Ano de Inscrição: ");
        anoInscr = entrada.nextInt();
        entrada.nextLine();
        
        System.out.println(" Informe a Base bonus de Pessoa Fisica: ");
        base = entrada.nextDouble();
        entrada.nextLine();
        PessoaFisica pessoaf = new PessoaFisica(cpf, nome, anoInscr);
        pessoaf.setBase(base);
        
        System.out.println("Digite seu CGC: ");
        cgc = entrada.nextLine();
        
        System.out.println("Digite seu Nome: ");
        nome = entrada.nextLine();
        
        System.out.println("Informe o Ano de Inscrição: ");
        anoInscr = entrada.nextInt();
        entrada.nextLine();
        
        System.out.println("Informe a taxa de Incentivo de Pessoa Juridica: ");
        ti = entrada.nextDouble();
        PessoaJuridica pessoaj = new PessoaJuridica(cpf, nome, anoInscr);
        pessoaj.setTaxaIncentivo(ti);
        
        do {
            System.out.println("\n 1- Consulta Pessoa Fisica \n 2- Consulta Pessoa Juridica \n 3- Adicionar compras \n 4- Sair");
            opcao = entrada.nextInt();
        
            switch(opcao) {
                case 1:
                    System.out.println("Nome: " + pessoaf.getNome());
                    System.out.println("CPF: " + pessoaf.getCpf());
                    System.out.println("Ano de inscrição " + pessoaf.getAnoInscr());
                    System.out.println("Bonus: " + df.format(pessoaf.calcBonus(aAtual)));
                    System.out.println("Total de Compras: " + df.format(pessoaf.getTotalCompras()));
                    break;
                
                case 2:
                    System.out.println("Nome: " + pessoaj.getNome());
                    System.out.println("CGC: " + pessoaj.getCgc());
                    System.out.println("Ano de Inscricao: " + pessoaj.getAnoInscr());
                    System.out.println("Taxa de Incentivo: " + df.format(pessoaj.getTaxaIncentivo()));
                    System.out.println("Bonus: " + df.format(pessoaj.calcBonus(aAtual)));
                    System.out.println("Total de Compras: " + df.format(pessoaj.getTotalCompras()));
                    break;
                    
                case 3:
                    System.out.println("Adicionar compras a: 1- Pessoa Fisica / 2- Pessoa Juridica");
                    entrada.nextLine();
                    opcao2 = entrada.nextInt();
                    
                    if (opcao2 == 1) {
                        System.out.println("Digite o valor: ");
                        compras = entrada.nextDouble();
                        pessoaf.addCompras(compras);
                    }else {
                        System.out.println("Digite o valor: ");
                        compras = entrada.nextDouble();
                        pessoaj.addCompras(compras);
                    }
                    
                case 4:
                    break;
            }
        }
        while (opcao < 4);
    }   
}
