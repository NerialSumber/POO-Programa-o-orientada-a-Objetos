
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class Palestrante extends Pessoa {
    private String empresa;
    private double taxaCobranca;
    
    public Palestrante(String cpf, String nome, String empresa) {
        super(cpf, nome);
        this.empresa = empresa;
    }
    
    public void setTaxaCobranca(double taxaCobranca) {
        this.taxaCobranca = taxaCobranca;
    }

    public String getEmpresa() {
        return empresa;
    }

    public double getTaxaCobranca() {
        return taxaCobranca;
    }
    
    /*public double calcTotalReceberPalestras() {
        return ();
    }*/
}
