
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class Pessoa {
    private String cpf, nome;
    
    public Pessoa(String cpf, String nome) {
        this.cpf = cpf;
        this.nome = nome;
    }
    
    private String getCpf() {
        return cpf;
    }
    
    private String getNome() {
        return nome;
    }
}
