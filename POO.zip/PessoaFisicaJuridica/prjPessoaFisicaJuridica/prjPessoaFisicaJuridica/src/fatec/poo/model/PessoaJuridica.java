
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class PessoaJuridica extends Pessoa {
    private String cgc;
    private double taxaIncentivo;
    
    public PessoaJuridica(String n, int ai, String cad) {
        super(n, ai);
        cgc = cad;
    }
    
    public double calcBonus(int ano) {
        return (((taxaIncentivo/100) * super.getTotalCompras()) * (ano - super.getAnoInscricao()));
    }
    
    public void setTaxaIncentivo(double ti) {
        taxaIncentivo = ti;
    }
    
    public double getTaxaIncentivo() {
        return taxaIncentivo;
    }
    
    public String getCgc() {
        return cgc;
    }
}
