
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class PessoaFisica extends Pessoa{
    private String cpf;
    private double base;
    
    public PessoaFisica(String n, int ai, String cad) {
        super(n, ai);
        cpf = cad;
    }
    
    public double calcBonus(int ano) {
        if(super.getTotalCompras() > 12000) {
            return ((ano - super.getAnoInscricao()) * base);
        }
        else {
            return 0;
        }
    }
    
    public String getCpf() {
        return cpf;
    }
    
    public void setBase(double b) {
        base = b;
    }
    
    public double getBase() {
        return base;
    }
}
