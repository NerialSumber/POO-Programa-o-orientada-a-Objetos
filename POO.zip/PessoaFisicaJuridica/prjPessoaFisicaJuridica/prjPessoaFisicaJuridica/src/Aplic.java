
import fatec.poo.model.PessoaFisica;
import fatec.poo.model.PessoaJuridica;
import java.text.DecimalFormat;
import java.util.Scanner;


/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        String nome, cpfPf, cgcPj;
        int anoInsc, opcao, anoAtual;
        double basePf, taxaIncPj, compra;
        
        System.out.println("Digite o ano atual: ");
        anoAtual = entrada.nextInt();
        
        System.out.println("\n\n\t\tPESSOA FÍSICA");
        System.out.println("Digite o nome: ");
        entrada.nextLine();
        nome = entrada.nextLine();
        System.out.println("Digite o ano de inscrição: ");
        anoInsc = entrada.nextInt();
        System.out.println("Digite o cpf: ");
        cpfPf = entrada.next();
        System.out.println("Digite a base: ");
        basePf = entrada.nextDouble();
        
        PessoaFisica objPesFisica = new PessoaFisica(nome, anoInsc, cpfPf);
        objPesFisica.setBase(basePf);
        
        do {
            System.out.println("\nFoi realizado alguma compra?");
            System.out.println("1 - Sim");
            System.out.println("2 - Não");
            System.out.println("Digite a opção: ");
            opcao = entrada.nextInt();
            
            switch (opcao) {
                case 1: 
                    System.out.println("Digite o valor da compra: ");
                    compra = entrada.nextDouble();
                    objPesFisica.addCompras(compra);
                    break;
                case 2:
                    break;
            }
        } while(opcao == 1);
        
        System.out.println("\n\n\t\tPESSOA JURÍDICA");
        System.out.println("Digite o nome: ");
        entrada.nextLine();
        nome = entrada.nextLine();
        System.out.println("Digite o ano de inscrição: ");
        anoInsc = entrada.nextInt();
        System.out.println("Digite o cgc: ");
        cgcPj = entrada.next();
        System.out.println("Digite a taxa de incentivo: ");
        taxaIncPj = entrada.nextDouble();
        
        PessoaJuridica objPesJuridica = new PessoaJuridica(nome, anoInsc, cgcPj);
        objPesJuridica.setTaxaIncentivo(taxaIncPj);
        
        do {
           System.out.println("\nFoi realizado alguma compra?");
           System.out.println("1 - Sim");
           System.out.println("2 - Não");
           System.out.println("Digite a opção: ");
           opcao = entrada.nextInt();
            
           switch (opcao) {
               case 1: 
                   System.out.println("Digite o valor da compra: ");
                   compra = entrada.nextDouble();
                   objPesJuridica.addCompras(compra);
                   break;
               case 2:
                   break;
            }
        } while(opcao == 1);
         
        System.out.println("\n\n\t\tPESSOA FÍSICA");
        System.out.println("Nome: " + objPesFisica.getNome());
        System.out.println("Ano de Inscrição: " + objPesFisica.getAnoInscricao());
        System.out.println("CPF: " + objPesFisica.getCpf());
        System.out.println("Base: " + df.format(objPesFisica.getBase()));
        System.out.println("- Bônus            => " + df.format(objPesFisica.calcBonus(anoAtual)));
        System.out.println("- Total de Compras => " + df.format(objPesFisica.getTotalCompras()));        
        
        System.out.println("\n\t\tPESSOA JURÍDICA");
        System.out.println("Nome: " + objPesJuridica.getNome());
        System.out.println("Ano de Inscrição: " + objPesJuridica.getAnoInscricao());
        System.out.println("CGC: " + objPesJuridica.getCgc());
        System.out.println("Taxa de Incentivo: " + df.format(objPesJuridica.getTaxaIncentivo()) + "%");
        System.out.println("- Bônus            => " + df.format(objPesJuridica.calcBonus(anoAtual)));
        System.out.println("- Total de Compras => " + df.format(objPesJuridica.getTotalCompras()));
    }
}
